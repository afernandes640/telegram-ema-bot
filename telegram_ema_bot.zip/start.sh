#!/bin/bash
export BOT_TOKEN=$BOT_TOKEN
export USER_ID=$USER_ID
python bot.py
